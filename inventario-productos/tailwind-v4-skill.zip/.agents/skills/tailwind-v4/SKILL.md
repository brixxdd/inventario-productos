---
name: tailwind-v4
description: Instala, configura y aplica Tailwind CSS v4 con Vite. Usar cuando el usuario necesite instalar Tailwind, crear componentes UI, aplicar estilos, diseñar layouts o configurar el tema. Nunca usar métodos de Tailwind v3.
---

# Tailwind CSS v4 — Skill

## Cuándo usar esta skill
- El usuario quiere instalar o configurar Tailwind CSS
- El usuario pide crear un componente, card, botón, layout o cualquier UI
- El usuario menciona estilos, diseño, colores o clases CSS
- El usuario tiene un error relacionado con Tailwind

---

## Instalación correcta (v4 con Vite)

### 1. Instalar paquetes
```bash
npm install tailwindcss @tailwindcss/vite
```

### 2. Configurar vite.config.ts
```ts
import { defineConfig } from 'vite'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [
    tailwindcss(),
  ],
})
```

### 3. CSS principal
```css
@import "tailwindcss";
```

### ❌ NUNCA hacer esto (es Tailwind v3, está obsoleto)
- `npx tailwindcss init`
- `tailwind.config.js`
- `@tailwind base;` / `@tailwind components;` / `@tailwind utilities;`
- `npm install -D tailwindcss postcss autoprefixer`

### Context7
- Para documentación actualizada usar: `/tailwindlabs/tailwindcss.com`

---

## Design System — Tema con CSS (NO config.js)

```css
@import "tailwindcss";

@theme {
  --color-primary-500: oklch(0.55 0.22 260);
  --color-primary-900: oklch(0.25 0.15 265);
  --color-accent:      oklch(0.70 0.18 140);
  --font-sans: 'Geist Sans', system-ui, sans-serif;
  --radius-md: 0.5rem;
  --radius-lg: 1rem;
  --radius-xl: 1.5rem;
}
```

- Usar `oklch()` en lugar de hex para colores más vívidos
- Tailwind v4 soporta P3 color gamut por defecto

---

## Patrones de Layout

### Contenedor base
```html
<div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
```

### Hero centrado
```html
<section class="min-h-screen flex items-center justify-center text-center px-4">
```

### Grid responsivo
```html
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
```

### Sidebar + Main
```html
<div class="flex min-h-screen">
  <aside class="w-64 shrink-0 bg-gray-900 text-white p-4"></aside>
  <main class="flex-1 p-6 overflow-y-auto"></main>
</div>
```

### Sticky footer
```html
<body class="min-h-screen flex flex-col">
  <main class="flex-1"></main>
  <footer></footer>
</body>
```

---

## Componentes Modernos

### Card con hover
```html
<div class="rounded-2xl bg-white shadow-md hover:shadow-xl transition-shadow duration-300 p-6 border border-gray-100">
```

### Card oscura (dark mode ready)
```html
<div class="rounded-2xl bg-gray-900 text-white shadow-lg p-6 border border-white/10">
```

### Glassmorphism
```html
<div class="backdrop-blur-md bg-white/10 border border-white/20 rounded-2xl shadow-xl p-6">
```

### Botón primario
```html
<button class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors duration-200 cursor-pointer">
```

### Botón outline
```html
<button class="border border-blue-600 text-blue-600 hover:bg-blue-50 font-semibold px-6 py-3 rounded-xl transition-colors duration-200">
```

### Badge / chip
```html
<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
```

### Input moderno
```html
<input class="w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-blue-500 transition">
```

### Tabla
```html
<div class="overflow-hidden rounded-2xl border border-gray-200 shadow-sm">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-gray-500 uppercase text-xs">
      <tr>
        <th class="px-6 py-4 text-left font-medium">Columna</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-100">
      <tr class="hover:bg-gray-50 transition-colors">
        <td class="px-6 py-4 text-gray-700">Dato</td>
      </tr>
    </tbody>
  </table>
</div>
```

---

## Tipografía

```html
<!-- Hero heading -->
<h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-balance text-gray-900">

<!-- Subheading -->
<h2 class="text-2xl sm:text-3xl font-semibold text-gray-800">

<!-- Párrafo -->
<p class="text-base text-gray-600 text-pretty leading-relaxed max-w-2xl">

<!-- Label pequeño -->
<span class="text-xs font-medium uppercase tracking-widest text-gray-500">
```

- `text-balance` → headings (distribuye palabras mejor)
- `text-pretty` → párrafos (evita palabras sueltas al final)

---

## Árbol de decisiones

| Situación | Solución |
|-----------|----------|
| Instalar Tailwind | `npm install tailwindcss @tailwindcss/vite` |
| Personalizar colores/fuentes | `@theme {}` en el CSS |
| Componente con hover | `hover:` + `transition-*` |
| Layout complejo | `grid` o `flex` con breakpoints `sm:` `lg:` |
| Dark mode | `dark:` variant o colores con `/opacity` |
| Animación | `transition-*` + `duration-*` + `ease-*` |

---

## Reglas duras
- ❌ NO usar `@apply` en proyectos nuevos
- ❌ NO usar `tailwind.config.js`
- ✅ Siempre mobile-first (sin prefijo → `sm:` → `lg:`)
- ✅ Usar `container queries` con `@container` cuando sea posible
